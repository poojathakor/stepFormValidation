$("#prevBtn3").on("click",function(){
    $(".tab1").hide();
    $(".tab2").show();
    $(".tab3").hide();
});
$("#prevBtn2").on("click",function(){
    $(".tab1").show();
    $(".tab2").hide();
    $(".tab3").hide();
});
function validateEmail(email) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(email)) {
        return true;
    }else{
        return false;
    }
}
// function validatePwd(pwd) {
//     var filter = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])$/;
//     if (filter.test(pwd)) {
//         return true;
//     }else{
//         return false;
//     }
// }
function Tab1Validate()
{
    num = /[0-9]/ ;
    special_char = /[!@#$%^&*()?{}]/;
    char = /[A-Za-z]/;
    if ($("#fname").val() == "") {
        $("#fname").addClass("error_cls");
        msgbox("Firstname is required","fname");
        $('#fname').focus();
       return false;
      }
     if ($("#lname").val() == "") {
        $("#lname").addClass("error_cls");
        msgbox("Lastname is required","lname");
        $('#lname').focus();
        return false;
    }
     if ($("#uname").val() == "") {
        $("#uname").addClass("error_cls");
        msgbox("Username is required","uname");
        $('#uname').focus();
        return false;
    }
     if ($("#pword").val() == "") {
        $("#pword").addClass("error_cls");
        msgbox("Password is required","pword");
        $('#pword').focus();
        return false;
    }
     if($("#pword").val().length < 8) {
        $("#pword").addClass("error_cls");
        msgbox_length("Length of Password must be greater than or equal to 8","pword");
        $('#pword').focus();
        return false;
    }
    // else if (validatePwd($("#pword").val()) == "") {
    //     $("#pword").addClass("error_cls");
    //     msgbox_valid("Please enter Strong Password address","pword");
    //     $('#pword').focus();
    //     return false;
    // }
     if((!num.test($("#pword").val())) || (!char.test($("#pword").val())) || (!special_char.test($("#pword").val()))){
        $("#pword").addClass("error_cls");
        msgbox_valid("Password must be strong","pword");
        $('#pword').focus();
        return false;
    }
     if ($("#cpword").val() == "") {
        $("#cpword").addClass("error_cls");
        msgbox("Confirm Password is required","cpword");
        $('#cpword').focus();
        return false;
    }
     if(($("#cpword").val()) !== ($("#pword").val())){
        $("#cpword").addClass("error_cls");
        msgbox_length("Confirm Password must be same as password","cpword");
        $('#cpword').focus();
        return false;
    }
    else{
        $(".tab1").hide();
        $(".tab2").show();
        $(".tab3").hide();
    }
}
function Tab2Validate()
{
    if ($("#email").val() == "") {
        $("#email").addClass("error_cls");
        msgbox("email is required","email");
        $('#email').focus();
        return false;
    }
    if (validateEmail($("#email").val()) == "") {
        $("#email").addClass("error_cls");
        msgbox_length("Please enter valid email address","email");
        $('#email').focus();
        return false;
    }
    if ($("#datepicker").val() == "") {
        $("#datepicker").addClass("error_cls");
        msgbox("DOB is required","datepicker");
        $('#datepicker').focus();
        return false;
    }
    else{
        $(".tab1").hide();
        $(".tab2").hide();
        $(".tab3").show();
    }
}
function Tab3Validate()
{
    if ($("#gender").val() == "") {
        $("#gender").addClass("error_cls");
        msgbox("gender is required","gender");
        $('#gender').focus();
        return false;
    }
    if (!($("#agree").is(":checked"))) {
        $("#agree").addClass("error_cls");
        msgbox("Please accept out policies","agree");
        $('#agree').focus();
        return false;
    }
    else{
        $("#regForm").submit();
    }
}
function msgbox(msg,id){
    $("."+id+"_error").html(msg);
}
function msgbox_length(msg,id){
    $("."+id+"_length").html(msg);
}
function msgbox_valid(msg,id){
    $("."+id+"_valid").html(msg);
}
$(document).ready(function(){
    $("#fname").on("keydown",function(){
        $("#fname").removeClass("error_cls");
        $(".fname_error").text("");
    });
    $("#lname").on("keydown",function(){
        $("#lname").removeClass("error_cls");
        $(".lname_error").text("");
    });
    $("#uname").on("keydown",function(){
        $("#uname").removeClass("error_cls");
        $(".uname_error").text("");
    });
    $("#pword").on("keydown",function(){
        $("#pword").removeClass("error_cls");
        $(".pword_error").text("");
        if($("#pword").val().length>8){
            $(".pword_length").text("");
        }
        else if((num.test($("#pword").val())) || (char.test($("#pword").val())) || (special_char.test($("#pword").val()))){
            $(".pword_valid").text("");
        }
    });
    $("#cpword").on("keydown, blur",function(){
        $("#cpword").removeClass("error_cls");
        $(".cpword_error").text("");
        if(($("#cpword").val()) === ($("#pword").val())){
            $(".cpword_length").text("");
        }
    });
    $("#email").on("keydown",function(){
        $("#email").removeClass("error_cls");
        $(".email_error").text("");
        if (validateEmail($("#email").val()) != ""){
            $(".email_length").text("");
        }
    });
    $("#datepicker").on("keydown",function(){
        $("#datepicker").removeClass("error_cls");
        $(".datepicker_error").text("");
    });
    $("#gender").on("click",function(){
        $("#gender").removeClass("error_cls");
        $(".gender_error").text("");
    });
    $("#agree").on("click",function(){
        $("#agree").removeClass("error_cls");
        $(".agree_error").text("");
    });
    
     //    if($("#agree").is(":checked")){
	    //     $("#agree").removeClass("error_cls");
	    //     $(".agree_error").empty();
    	// }
    // if($("#agree").is(":checked")){
    //     $("#agree").removeClass("error_cls");
    //     $(".agree_error").hide();
    // }


    $("#gender").on("change",function(){
        var gender = ($("#gender").val());
        var age_cal = ($("#age_cal").val());
        if(age_cal >= 18 && gender=="Male")
        {
            $('#agree').prop('checked', true);
            $('#agree-error').hide();
        }
        else {
            $('#agree').prop('checked', false);
        }
    });
    


    $("#datepicker").datepicker({
        maxDate: '+0d',     
        yearRange: '1914:3025',
        buttonImageOnly: true,
        changeMonth: true,
        changeYear: true,
       
    }).on('change', function () {
        var age = getAge(this);
        var age_cal = getAgeYearCall(this);
        $("#age").html("You are " + age + " old");
        $("#age_cal").val(age_cal);
    });

    function getAge(dateVal) {
        var
            birthday = new Date(dateVal.value),
            today = new Date(),
            ageInMilliseconds = new Date(today - birthday),
            years = ageInMilliseconds / (24 * 60 * 60 * 1000 * 365.25 ),
            months = 12 * (years % 1),
            days = Math.floor(30 * (months % 1));
            return Math.floor(years) + ' years ' + Math.floor(months) + ' months ' + days + ' days';
    }
    function getAgeYearCall(dateVall) {
        var
            birthday = new Date(dateVall.value),
            today = new Date(),
            ageInMilliseconds = new Date(today - birthday),
            years = ageInMilliseconds / (24 * 60 * 60 * 1000 * 365.25 ),
            months = 12 * (years % 1),
            days = Math.floor(30 * (months % 1));
            return Math.floor(years);
    }

});

  